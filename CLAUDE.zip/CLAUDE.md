# PyHire — AI Recruiting Platform (Marketing Website)

> Comprehensive technical and product documentation for this repository.
> Last analyzed: 2026-08-06

---

## Table of Contents

1. [Product Overview](#1-product-overview)
2. [Business Logic](#2-business-logic)
3. [Technical Architecture](#3-technical-architecture)
4. [Folder Structure](#4-folder-structure)
5. [Feature Documentation](#5-feature-documentation)
6. [Module Documentation](#6-module-documentation)
7. [API Documentation](#7-api-documentation)
8. [Database Relationships](#8-database-relationships)
9. [User Workflows](#9-user-workflows)
10. [Important Files](#10-important-files)
11. [Business Benefits](#11-business-benefits)
12. [Development Workflow](#12-development-workflow)
13. [Known Gaps & Technical Debt](#13-known-gaps--technical-debt)

---

## 1. Product Overview

### What this repository is

This repository contains the **public-facing marketing website** for **PyHire**, an AI-powered Recruitment Operating System (ROS). It is a **client-side-only React single-page application**. It markets the PyHire product; it is **not** the PyHire product itself.

**Critical distinction:** the eight "Platform" pages describe ATS/CRM capabilities (candidate databases, AI matching, interview scheduling, analytics). None of that functionality is implemented here — those pages are static marketing content rendered from hard-coded arrays. There is no backend, no database, no authentication, and no live AI inference in this codebase. See [Section 13](#13-known-gaps--technical-debt).

### The product being marketed

**PyHire** is positioned as a single intelligent platform covering the complete hiring lifecycle — job creation → candidate sourcing → AI matching → interviews → offers → analytics — for:

| Segment | Primary need PyHire addresses |
|---|---|
| Recruitment agencies | Multi-client requisition and submittal management |
| Staffing firms | Vendor collaboration, contracts, placement tracking |
| In-house HR / TA teams | Pipeline automation, recruiter productivity, hiring analytics |
| Enterprise buyers | Role-based access, audit trails, DPDPA/GDPR-aligned governance |

### Brand and positioning

- **Product name:** PyHire
- **Headline (home hero):** *"Hire people, not paperwork."*
- **Value proposition:** *"PyHire sources, screens and shortlists candidates automatically — so your team spends its time on interviews and decisions, not spreadsheets and inboxes."*
- **Mission statement:** *"To make hiring products radically simple, powerful, and accessible."*
- **Primary CTAs:** "Book a Demo", "Request Demo", "Get Free Quote"
- **Primary brand color:** Orange `#f97316` (with `#ea580c` hover, `#FF6B00`/`#ff5a1f` variants in the chatbot and contact form)
- **Supporting palette:** off-white `#fdfdfd`, cream `#FFFCF4`, slate greys, `#f8fbfa` mint-white

### Marketing proof points (as published on the site)

Source: [src/components/Mission.tsx](src/components/Mission.tsx)

| Metric | Claim |
|---|---|
| Profiles processed (last 6 months) | 1M |
| Profiles processed daily | 10K+ |
| In-app review score (Interviews module) | 9.2 / 10 |
| AI accuracy rate | 99.87% |
| Candidate matching accuracy | 99.3% |

### Contact and conversion details

Present in both [src/components/Footer.tsx](src/components/Footer.tsx) and [src/pages/ContactUs.tsx](src/pages/ContactUs.tsx):

- **Phone:** +91 9964667676
- **Email:** support@veriright.com
- **Office hours:** Mon–Sat, 9:30 AM – 7:00 PM IST
- **Implied market:** India-first (DPDPA alignment, IST hours, +91 number, India-focused blog content), with global compliance messaging (GDPR/CCPA) for enterprise buyers.

---

## 2. Business Logic

This is a **conversion-oriented marketing site**. Its "business logic" is not transactional processing — it is the funnel design, the content model, and the small amount of client-side interaction logic that supports them.

### 2.1 Conversion funnel

```
Traffic
  │
  ├─► Home (/)                      ── broad value prop + social proof
  │      └─ Hero CTA: "Book a Demo" / "Get Free Quote"
  │
  ├─► Platform pages (8 routes)     ── capability-specific deep dives
  │      └─ Repeated CTA: "Request Demo" (hero) + "Book a Demo Today" (footer CTA block)
  │
  ├─► About Us / Blog               ── trust and authority building
  │
  └─► Contact Us (/contact-us)      ── lead capture form
         └─ Persistent: Navbar "Request Demo" + floating ChatbotWidget on every page
```

Every route renders the same persistent conversion surfaces:
- **Navbar** — sticky "Request Demo" button (desktop and mobile)
- **Footer** — newsletter signup + full platform/company sitemap + contact block
- **ChatbotWidget** — floating orange bot button, bottom-right, on 100% of pages

### 2.2 Content model as business logic

The site's core architectural decision is that **product marketing content is data, not markup**. Each of the 8 platform pages is a data object passed into one shared layout component.

The canonical content contract (`ProductPageProps` in [src/components/ProductPageLayout.tsx:5](src/components/ProductPageLayout.tsx#L5)) encodes the standard B2B SaaS sales narrative:

| Content slot | Sales purpose |
|---|---|
| `title` + `description` | Positioning statement — what the module is |
| `features[]` (4 items) | Capability proof — what it does |
| `workflowSteps[]` (6 items) | Process credibility — how it works end-to-end |
| `benefits[]` (4 items) | Outcome framing — why it matters commercially |
| `faqs[]` (3 items) | Objection handling — de-risk the purchase |
| `ctaTitle` / `ctaDesc` | Conversion ask — book a demo |

**Business consequence:** launching a new product module page requires authoring one data object (~40 lines), not building a page. Narrative consistency across all modules is enforced structurally.

### 2.3 Interactive business logic (the only real logic in the codebase)

| Logic | Location | Behavior |
|---|---|---|
| **FAQ knowledge-base search** | [src/components/FAQ.tsx:67](src/components/FAQ.tsx#L67) | Case-insensitive substring match of the user query against a local 9-entry `knowledgeBase` array (question text and answer text). First match wins; result scrolls into view. On no match, shows a fallback prompt. |
| **Chatbot conversation** | [src/components/ChatbotWidget.tsx:26](src/components/ChatbotWidget.tsx#L26) | Appends the user message to local state, then after a 1000 ms `setTimeout` appends a **fixed canned reply**: *"Thanks for your message! Our team will get back to you shortly…"*. No network call, no AI. |
| **Active-route highlighting** | [src/components/Navbar.tsx](src/components/Navbar.tsx) | `useLocation().pathname` compared against link paths; matching link renders in brand orange + bold. |
| **Scroll-state navbar** | [src/components/Navbar.tsx:11](src/components/Navbar.tsx#L11) | Past 10 px scroll, header switches from transparent to `bg-white/90` + backdrop blur + shadow. |
| **FAQ accordion** | [src/components/ProductPageLayout.tsx:53](src/components/ProductPageLayout.tsx#L53) | Single-open accordion via `openIdx` state; index `0` open by default, clicking the open item sets `-1` (all closed). |
| **Scroll restoration** | `useEffect` in every page component | `window.scrollTo(0, 0)` on mount, since React Router does not reset scroll between routes. |

### 2.4 Lead-capture logic — current state

**The contact form does not submit.** [src/pages/ContactUs.tsx:57](src/pages/ContactUs.tsx#L57) renders a `<form>` with First Name, Last Name, Email, Phone, Subject, Message, and a consent checkbox — but the fields are uncontrolled (no `useState`), there is no `onSubmit` handler, and the submit control is `<button type="button">`, which deliberately does not trigger form submission. Leads entered here are silently discarded.

The same is true of the footer newsletter input and the chatbot. **All lead capture on this site is currently non-functional** and must be wired before launch. See [Section 13](#13-known-gaps--technical-debt).

---

## 3. Technical Architecture

### 3.1 Stack

| Layer | Technology | Version | Notes |
|---|---|---|---|
| UI framework | React | ^19.0.1 | Function components + hooks only; no class components |
| Language | TypeScript | ~5.8.2 | `noEmit` — type-check only, Vite handles transpilation |
| Build tool | Vite | ^6.2.3 | With `@vitejs/plugin-react` ^5.0.4 |
| Routing | react-router-dom | ^7.18.2 | `BrowserRouter`, client-side only |
| Styling | Tailwind CSS | ^4.1.14 | Via the `@tailwindcss/vite` plugin — **no `tailwind.config.js`** |
| Animation | motion (Framer Motion) | ^12.23.24 | Imported as `motion/react` |
| Icons | lucide-react | ^0.546.0 | Sole icon system |
| Package manager | Bun or npm | — | Both `bun.lock` and `package-lock.json` are committed |

**Declared but unused in `src/`:** `@google/genai`, `express`, `dotenv`, `tsx`, `esbuild`, `autoprefixer`. These are inherited from the Google AI Studio scaffold. A repo-wide search for `genai`, `GoogleGenAI`, `GEMINI`, `fetch(`, `axios`, `express`, and `process.env` inside `src/` returns **zero matches**.

### 3.2 Architectural shape

```
┌──────────────────────────────────────────────────────────┐
│  index.html   →   src/main.tsx   (createRoot + StrictMode)│
└───────────────────────────┬──────────────────────────────┘
                            ▼
┌──────────────────────────────────────────────────────────┐
│  src/App.tsx  —  BrowserRouter shell                      │
│  ┌────────────────────────────────────────────────────┐  │
│  │  <Navbar />           persistent, fixed, z-50       │  │
│  ├────────────────────────────────────────────────────┤  │
│  │  <Routes>  12 routes  ← the only swapping region    │  │
│  ├────────────────────────────────────────────────────┤  │
│  │  <Footer />           persistent                    │  │
│  │  <ChatbotWidget />    persistent, fixed, z-50       │  │
│  └────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────┘
```

Layout root: `min-h-screen flex flex-col bg-slate-50 font-sans selection:bg-emerald-200`.

### 3.3 Core architectural patterns

**Pattern 1 — Layout inversion / data-driven pages (the most important pattern in the repo)**

Seven of the eight platform pages contain **no JSX layout of their own**. They export a single function that returns `<ProductPageLayout {...contentObject} />`. All visual structure lives in one file.

```
JobManagement.tsx ─┐
AICandidateMatching.tsx ─┤
InterviewManagement.tsx ─┤
ClientVendorManagement.tsx ─┼──► ProductPageLayout.tsx ──► rendered page
UnifiedCommunication.tsx ─┤        (single source of
AnalyticsDashboards.tsx ─┤         layout truth)
ComplianceSecurity.tsx ─┘
```

**Editing `ProductPageLayout.tsx` changes seven pages simultaneously.** This is the highest-blast-radius file in the codebase.

**Pattern 2 — Custom hero override**

Each product page supplies a bespoke hero via the `customHero?: React.ReactNode` prop, paired with a dedicated `*Hero.tsx` component. When `customHero` is provided, the layout's generic hero is bypassed entirely ([ProductPageLayout.tsx:59](src/components/ProductPageLayout.tsx#L59)). All 8 product pages use this override, which means the `hero: { imageSrc }` prop each page still passes is **dead data** — never rendered.

**Pattern 3 — CSS-only infinite marquees**

Three distinct marquee animations are implemented with inline `<style>` blocks and `animate-[name_duration_linear_infinite]` arbitrary Tailwind values, all pausable on hover via `group-hover:[animation-play-state:paused]`:

| Animation | Where | Technique |
|---|---|---|
| `marquee` (horizontal, features) | ProductPageLayout | Array tripled `[...features, ...features, ...features]`, translate to `-33.33%` |
| `marqueeWorkflow` (horizontal, timeline) | ProductPageLayout | Array doubled, translate to `-50%`, alternating above/below a centre rail |
| `marqueeVertical` (benefits column) | ProductPageLayout | Array doubled, `translateY(-50%)`, gradient masks top and bottom |
| `marqueeHorizontal` (wavy SVG timeline) | CandidateManagement | 5800 px-wide SVG bezier path with a gradient stroke, 18-column grid |

The seamless-loop invariant: **the duplication factor must match the translate percentage** (2× → −50%, 3× → −33.33%). Changing one without the other visibly breaks the loop.

**Pattern 4 — Utility-first styling with arbitrary values**

There is no design-token file and no `tailwind.config.js`. Tailwind v4 is configured entirely by the Vite plugin, and [src/index.css](src/index.css) contains exactly one line: `@import "tailwindcss";`. Consequently the design system lives as **repeated arbitrary values** across components — e.g. `text-[#f97316]`, `rounded-[32px]`, `text-[1.125rem]`, `shadow-[0_8px_30px_rgb(0,0,0,0.04)]`. A rebrand currently requires a global find-and-replace.

**Pattern 5 — Scroll-triggered reveal animations**

Motion's viewport API is used consistently for section entrances:
```tsx
initial={{ opacity: 0, y: 30 }}
whileInView={{ opacity: 1, y: 0 }}
viewport={{ once: true }}
transition={{ duration: 0.6 }}
```

### 3.4 Rendering and state model

- **No global state.** No Context, Redux, Zustand, or React Query anywhere.
- **No data fetching.** Zero network requests originate from application code.
- **All state is component-local `useState`** — 6 stateful components total (Navbar, FAQ, ChatbotWidget, ProductPageLayout, CandidateManagement, plus the router).
- **All content is compiled into the bundle** as literal arrays and JSX.

### 3.5 Asset strategy

| Asset type | Source | Risk |
|---|---|---|
| Product demo videos | `/public/*.mp4` (self-hosted) | 13.7 MB combined — significant load cost |
| Photography, avatars, mockup imagery | **Unsplash hot-links** (`images.unsplash.com`) | Third-party dependency; images break if Unsplash changes or blocks hotlinking |
| Icons | lucide-react (bundled SVG) | None |
| Illustrations, dashboards, charts | Hand-built JSX + inline SVG | None |

### 3.6 Responsive strategy

Mobile-first Tailwind breakpoints. Two notable patterns:
- **Navbar:** desktop hover-dropdown nav below `lg`, replaced by a `max-h`-transition mobile accordion.
- **Timelines:** the animated horizontal marquee timeline is `hidden lg:block` (or `hidden xl:block` on CandidateManagement); a simple stacked vertical card list renders as the mobile alternative. Both render the same `workflowSteps` data.

---

## 4. Folder Structure

```
ai-recruiting-platform/
│
├── CLAUDE.md                         ← this document
├── README.md                         ← AI Studio scaffold readme (stale)
├── index.html                        ← Vite entry; <title> still "My Google AI Studio App"
├── package.json                      ← name is still "react-example"
├── vite.config.ts                    ← React + Tailwind plugins, "@" alias, HMR toggle
├── tsconfig.json                     ← ES2022, bundler resolution, react-jsx, noEmit
├── metadata.json                     ← AI Studio app manifest
├── .env.example                      ← GEMINI_API_KEY, APP_URL (neither is read by src/)
├── .gitignore
├── bun.lock  /  package-lock.json    ← two lockfiles present
│
├── update_app.sh                     ← one-off codemod (already applied)
├── update_navbar.js                  ← one-off codemod (already applied)
├── update_product_layout.py          ← one-off codemod (already applied)
├── update_workflow.py                ← one-off codemod (already applied)
│
├── *.mp4 (2 files, ~13.7 MB)         ← originals, duplicated into public/
│
├── assets/
│   └── .aistudio/                    ← AI Studio metadata (empty but for .gitignore)
│
├── public/                           ← served at web root
│   ├── ai-recruitment-platform-mvp.mp4   (3.5 MB — home hero, autoplay loop)
│   ├── pyhire-demo.mp4                   (9.6 MB — VideoSection, user-controlled)
│   └── candidate-banner.png              (1.3 MB)
│
└── src/
    ├── main.tsx                      ← createRoot + StrictMode
    ├── App.tsx                       ← router shell + persistent chrome
    ├── index.css                     ← @import "tailwindcss";  (1 line)
    │
    ├── components/                   ← 16 shared / home-page components
    │   ├── Navbar.tsx                    persistent — nav, dropdowns, mobile menu
    │   ├── Footer.tsx                    persistent — sitemap, newsletter, contact
    │   ├── ChatbotWidget.tsx             persistent — floating simulated assistant
    │   ├── ProductPageLayout.tsx     ★   shared layout driving 7 product pages
    │   ├── Hero.tsx                      home hero + autoplay MVP video
    │   ├── Mission.tsx                   mission statement + 5 KPI stat cards
    │   ├── Features.tsx                  11 capability cards with UI mockups
    │   ├── Compliance.tsx                DPDPA / HIPAA / ISO 27001 / SSO badges
    │   ├── FeatureHighlight.tsx          "Why Recruitment Teams Choose PyHire" diagram
    │   ├── VideoSection.tsx              "See PyHire in Action" demo player
    │   ├── Testimonials.tsx              3 anonymized customer quotes
    │   ├── FAQ.tsx                       searchable 9-entry knowledge base
    │   ├── FAQContact.tsx                contact prompt, embedded inside FAQ
    │   ├── Insights.tsx                  3 blog teaser cards
    │   ├── CTA.tsx                       "Ready to Transform Your Hiring?" closer
    │   └── LogoCloud.tsx             ⚠   defined but never imported (dead code)
    │
    └── pages/                        ← 12 routed pages + 8 hero partials
        ├── Home.tsx                      composes 10 home components
        ├── CandidateManagement.tsx   ★   bespoke page (37 KB, does NOT use the layout)
        ├── JobManagement.tsx             ┐
        ├── AICandidateMatching.tsx       │
        ├── InterviewManagement.tsx       │  7 data-only pages,
        ├── ClientVendorManagement.tsx    ├─ each ~70 lines of content
        ├── UnifiedCommunication.tsx      │  + a shared-layout call
        ├── AnalyticsDashboards.tsx       │
        ├── ComplianceSecurity.tsx        ┘
        ├── *Hero.tsx  (8 files)          bespoke hero per product page
        ├── AboutUs.tsx                   5-section company story
        ├── Blog.tsx                      article grid + sidebar (static)
        └── ContactUs.tsx                 lead form + contact info cards
```

**Convention note:** `src/pages/` mixes two responsibilities — routed page components and non-routed hero partials (`*Hero.tsx`). The hero partials are presentational components and would conventionally belong in `src/components/`.

---

## 5. Feature Documentation

### 5.1 Route map

| # | Route | Page component | Layout strategy |
|---|---|---|---|
| 1 | `/` | [Home.tsx](src/pages/Home.tsx) | Composes 10 section components |
| 2 | `/candidate-management` | [CandidateManagement.tsx](src/pages/CandidateManagement.tsx) | **Fully bespoke** |
| 3 | `/job-management` | [JobManagement.tsx](src/pages/JobManagement.tsx) | Shared layout + custom hero |
| 4 | `/ai-candidate-matching` | [AICandidateMatching.tsx](src/pages/AICandidateMatching.tsx) | Shared layout + custom hero |
| 5 | `/interview-management` | [InterviewManagement.tsx](src/pages/InterviewManagement.tsx) | Shared layout + custom hero |
| 6 | `/client-vendor-management` | [ClientVendorManagement.tsx](src/pages/ClientVendorManagement.tsx) | Shared layout + custom hero |
| 7 | `/unified-communication` | [UnifiedCommunication.tsx](src/pages/UnifiedCommunication.tsx) | Shared layout + custom hero |
| 8 | `/analytics-dashboards` | [AnalyticsDashboards.tsx](src/pages/AnalyticsDashboards.tsx) | Shared layout + custom hero |
| 9 | `/compliance-security` | [ComplianceSecurity.tsx](src/pages/ComplianceSecurity.tsx) | Shared layout + custom hero |
| 10 | `/about-us` | [AboutUs.tsx](src/pages/AboutUs.tsx) | Bespoke, 5 sections |
| 11 | `/blog` | [Blog.tsx](src/pages/Blog.tsx) | Bespoke, grid + sidebar |
| 12 | `/contact-us` | [ContactUs.tsx](src/pages/ContactUs.tsx) | Bespoke, form + info cards |

**No catch-all `*` route exists** — unknown URLs render the Navbar and Footer with a blank content area rather than a 404 page.

Two navigation entries are placeholders pointing at `#`: "Case Studies" (Navbar → Resources) and "Use Cases" (Footer → Company).

### 5.2 Home page composition

[src/pages/Home.tsx](src/pages/Home.tsx) renders, in order:

| Order | Component | Purpose |
|---|---|---|
| 1 | `Hero` | "Hire people, not paperwork." + autoplay MVP video + dual CTA |
| 2 | `Mission` | Mission statement + 5 KPI stat cards |
| 3 | `Features` | 11 capability cards, each with a hand-built UI mockup |
| 4 | `Compliance` | 4 enterprise compliance badges on a dotted cream panel |
| 5 | `FeatureHighlight` | "Why Recruitment Teams Choose PyHire" node-and-edge SVG diagram |
| 6 | `VideoSection` | "See PyHire in Action" — full demo video with controls |
| 7 | `Testimonials` | 3 anonymized customer quotes |
| 8 | `FAQ` | Searchable knowledge base (embeds `FAQContact` at its foot) |
| 9 | `Insights` | 3 blog article teasers |
| 10 | `CTA` | Final conversion block + trust row |

### 5.3 Platform feature modules (the 8 marketed capabilities)

Each module below is one navigation item, one route, one footer link, and one card in the home `Features` grid.

#### Job Management — `/job-management`
> *"Create, publish, approve, and manage job openings efficiently from one platform."*

- **Features:** Smart Requisitions (AI-assisted JDs), Multi-level Approvals, One-Click Publishing (job boards + social + careers page), Dynamic Pipelines (custom stages per job)
- **Workflow:** Draft Requisition → Approval Chain → Job Description → Job Publishing → Sourcing Begins → Pipeline Management
- **Benefits:** Accelerate Approvals, Wider Reach, Better Organization, Cost Control
- **Stated integrations:** LinkedIn and other premium boards

#### AI Candidate Matching — `/ai-candidate-matching`
> *"Automatically match candidates to job openings using AI based on skills, experience, education, certifications, and job requirements."*

- **Features:** Deep Profile Analysis (context beyond keywords), Skill Graph Matching (adjacent skills), Instant Scoring, Bias Reduction
- **Workflow:** Job Requirements → Data Ingestion → Semantic Analysis → Scoring Generation → Ranking → Recruiter Action
- **Benefits:** Save Hundreds of Hours, Improve Quality of Hire, Rediscover Silver Medalists, Scale Your Hiring
- **Stated model behavior:** criteria weights are recruiter-adjustable; the model refines against your organization's hiring outcomes over time

#### Candidate Management — `/candidate-management`
> *"PyHire simplifies candidate management with AI-powered automation, smarter workflows, and seamless collaboration."*

The only bespoke platform page. Documents six capabilities — Unified Candidate Profile, AI Candidate Matching, Resume Parsing, Smart Candidate Search, Automated Pipeline, Activity Timeline — and the flagship **9-step hiring lifecycle** (see [Section 9](#9-user-workflows)).

#### Interview Management — `/interview-management`
> *"Schedule interviews, coordinate interview panels, collect structured feedback, and manage interview workflows from one platform."*

- **Features:** Smart Scheduling (calendar sync), Video Integration, Structured Scorecards, Panel Coordination
- **Benefits:** Eliminate Scheduling Ping-Pong, Objective Evaluations, Faster Feedback Loops, better Candidate Experience
- **Stated integrations:** Zoom, Microsoft Teams, Google Meet

#### Client & Vendor Management — `/client-vendor-management`
> *"Manage clients, staffing vendors, contracts, requisitions, and recruitment collaboration from a centralized workspace."*

- **Features:** Client Portals (review/approve submittals), Vendor Collaboration (agency submissions per requisition), Contract Management (MSAs, SLAs, placement terms), Performance Tracking
- **Benefits:** Enhanced Client Experience, Streamlined Communication, Data Security via granular permissions, Vendor Accountability
- **Note:** this is the module that makes PyHire an agency/staffing product rather than an in-house-only ATS

#### Unified Communication — `/unified-communication`
> *"Manage Email, WhatsApp, SMS, Calling, and internal recruiter communication from one unified inbox."*

- **Features:** Omnichannel Inbox (single thread across channels), Automated Sequences (multi-channel drip nurture), Internal Collaboration (@mentions, private notes), Communication History (uneditable audit trail)
- **Benefits:** Higher Response Rates, No Context Switching, Perfect Team Alignment (prevents duplicate outreach), Instant Notifications

#### Analytics & Dashboards — `/analytics-dashboards`
> *"Track recruitment KPIs, hiring performance, recruiter productivity, pipeline analytics, source effectiveness, and executive dashboards in real time."*

- **Features:** Real-time Dashboards, Source Effectiveness, Time-to-Hire Tracking (stage-by-stage velocity), Recruiter Productivity
- **Benefits:** Optimize Spend, Improve Forecasting, Enhance Candidate Quality, Executive Visibility

#### Compliance & Security — `/compliance-security`
> *"Ensure secure recruitment with role-based access control, audit logs, GDPR compliance, document security, and enterprise-grade data protection."*

- **Features:** Enterprise Encryption (AES-256 at rest, TLS 1.2+ in transit), Role-Based Access, GDPR & CCPA Ready (anonymization, consent, right-to-be-forgotten), Comprehensive Audit Logs
- **Benefits:** Mitigate Risk, Global Compliance, Secure Collaboration, Automated Governance
- **Home-page compliance badges** ([Compliance.tsx](src/components/Compliance.tsx)): DPDPA *(aligned for India)*, HIPAA *(programme in progress)*, ISO 27001 *(aligned controls)*, SSO/SAML *(enterprise plan)* — note the deliberately hedged wording

### 5.4 Home `Features` grid — 11 capability cards

[src/components/Features.tsx](src/components/Features.tsx) contains the 8 platform modules plus 3 additional capabilities that have **no dedicated page**:

| Card | Has its own route? |
|---|---|
| Job Management, AI Candidate Matching, Candidate Management, Interview Management, Unified Communication, Client & Vendor Management, Recruitment Analytics, Compliance & Audit Trail | ✅ Yes |
| **Candidate Pipeline** | ❌ No |
| **AI Interviews** | ❌ No |
| **Role-Based Access** | ❌ No |

Each card embeds a hand-coded JSX mockup of the corresponding product UI — e.g. the AI Matching card shows ranked candidates with "98% Match" / "94% Match" badges; the Candidate Management card shows a donut chart reading 1,290 profiles / 490 active.

### 5.5 Supporting content features

**Blog** ([src/pages/Blog.tsx](src/pages/Blog.tsx)) — fully static. 4 article cards, a 6-category sidebar (Hiring Bias 6, Hiring Process 9, Psychology 7, Recruitment 12, Strategy 8, Technology 5), and 6 popular-article entries. **None of the article links navigate anywhere** — there is no article detail route and no CMS. The category counts are hard-coded and do not reflect the 4 articles actually rendered.

**About Us** ([src/pages/AboutUs.tsx](src/pages/AboutUs.tsx)) — 5 sections: Hero + photo gallery, Idea & Creation, Our Commitment, Our Mission (3 value cards: Visit Site, Target Oriented, Success Guarantee), and a closing CTA.

**FAQ knowledge base** ([src/components/FAQ.tsx](src/components/FAQ.tsx)) — 9 entries covering: what PyHire is, how AI matching works, staffing-agency support, multi-recruiter/multi-client management, HR system integration, data security, implementation time, workflow customization, and how to book a demo. Serves double duty as sales collateral and as objection handling.

---

## 6. Module Documentation

### 6.1 `ProductPageLayout` — the system's keystone

**File:** [src/components/ProductPageLayout.tsx](src/components/ProductPageLayout.tsx)
**Consumers:** 7 product pages
**Exports:** `ProductPageProps` (interface), `ProductPageLayout` (component)

Renders six sections in fixed order:

| § | Section | Behavior |
|---|---|---|
| 1 | Hero | Renders `customHero` if supplied; otherwise a generic centered hero with a video-or-image frame |
| 2 | Powerful Features | Horizontal marquee of 350 px cards, array tripled, 40 s loop, edge gradient masks, pauses on hover |
| 3 | Workflow | Desktop: animated alternating timeline on a centre rail. Mobile: stacked cards |
| 4 | Benefits | Two-column split — heading + image left, vertically scrolling benefit cards right (30 s loop) |
| 5 | FAQ | Single-open accordion, item 0 open by default |
| 6 | Final CTA | Cream rounded panel, circular image, "Book a Demo Today" |

Behavior on mount: `window.scrollTo(0, 0)`.

**Full props contract:**

```ts
interface ProductPageProps {
  hero: { imageSrc?: string; videoSrc?: string };   // ignored when customHero is set
  title: string;
  description: string;
  features:      { title: string; desc: string; icon: React.ReactNode }[];
  workflowTitle: string;
  workflowDesc:  string;
  workflowSteps: { id: string; title: string; desc: string; icon: React.ReactNode }[];
  benefitsTitle: string;
  benefitsDesc:  string;
  benefitsImage: string;                             // absolute URL
  benefits:      { title: string; desc: string; icon: React.ReactNode }[];
  faqsTitle: string;
  faqsDesc:  string;
  faqs: { q: string; a: string }[];
  ctaTitle: string;
  ctaDesc:  string;
  ctaImage: string;                                  // absolute URL
  customHero?: React.ReactNode;
}
```

**Content conventions observed across all consumers:** 4 features, 6 workflow steps (`id` as `"01"`…`"06"`), 4 benefits, 3 FAQs. Feature/benefit icons are passed unstyled (the layout colors them); workflow icons are passed pre-styled as `className="w-6 h-6 text-[#f97316]"`.

### 6.2 Persistent chrome modules

| Module | State | Responsibilities |
|---|---|---|
| **Navbar** | `isScrolled`, `isMobileMenuOpen`, `useLocation()` | Logo → `/`; Home; Platform dropdown (8 links); Resources dropdown (Blog, Case Studies); About Us; Contact; "Request Demo" CTA. Desktop dropdowns are pure CSS (`group-hover` + opacity/visibility); the mobile menu is a `max-h` transition accordion that closes on link click. |
| **Footer** | none | Newsletter signup block; social icon row (4 placeholder `#` links); Platform column (8 links); Company column (4 links, one placeholder); Contact Information block (phone/email/hours); legal row (Privacy Policy, Terms of Use — both `#`). |
| **ChatbotWidget** | `isOpen`, `messages`, `inputValue`, `messagesEndRef` | 360×500 px panel anchored bottom-right, `AnimatePresence` enter/exit. Seeds one bot greeting. Auto-scrolls to newest message on change. Submit disabled while input is empty. **Replies are canned; no AI or network involved.** |

### 6.3 Home section modules

| Module | Data shape | Notes |
|---|---|---|
| `Hero` | none (literal JSX) | Autoplaying muted looping `/ai-recruitment-platform-mvp.mp4` in an orange-bordered frame; decorative absolute-positioned shapes |
| `Mission` | `stats[5]` — `{value, label}` | `whitespace-pre-line` renders `\n` in labels; yellow blur glow behind the card row |
| `Features` | `cards[11]` — `{icon, title, description, mockup: JSX}` | The largest home component (24 KB); each `mockup` is a bespoke product-UI illustration |
| `Compliance` | `badges[4]` — `{icon, title, desc}` | Dotted radial-gradient background; amber status dot conditionally rendered for HIPAA only |
| `FeatureHighlight` | literal JSX | Node-and-edge diagram using a `viewBox="0 0 100 100"` SVG with dashed bezier connectors and absolutely-positioned percentage-based nodes |
| `VideoSection` | none | User-controlled demo player, `preload="metadata"` |
| `Testimonials` | `testimonials[3]` — `{text, author, role, image}` | Authors are anonymized by company type (Technology Startup / D2C Brand / Manufacturing Company) |
| `FAQ` | `knowledgeBase[9]` — `{question, answer}` | Search + click-to-expand; embeds `FAQContact` at its foot to share the background glow |
| `Insights` | `articles[3]` — `{title, …}` | Teal `#0f766e` hover accent — the one place the brand orange is not used |
| `CTA` | literal JSX | Dual CTA + a 4-item trust row with emerald check icons |

### 6.4 `CandidateManagement` — the bespoke outlier

**File:** [src/pages/CandidateManagement.tsx](src/pages/CandidateManagement.tsx) (37 KB — the largest file in the repo)

Does not use `ProductPageLayout`. Contains its own section stack plus internal sub-components defined in the same file (a benefits section at line 415, an accordion FAQ at line 536 with its own `openIdx` state, and a CTA at line 584).

Its signature element is the **9-step wavy timeline**: an 18-column grid across a 5800 px canvas, with a hand-plotted quadratic-bezier SVG path (`M 0 100 Q 161 160, 322 100 T 644 100 T …`) carrying a fading orange gradient stroke, nodes alternating above and below the wave, animated as a 40 s marquee with a doubled step array. It renders only at `xl` and above; smaller viewports get a stacked card list.

**Maintenance warning:** the wave path, the `5800px` container width, the `repeat(18,1fr)` grid, and the doubled 9-step array are mutually dependent constants. Changing the number of steps requires recomputing all four.

### 6.5 Dead and duplicated code

| Item | Status |
|---|---|
| [src/components/LogoCloud.tsx](src/components/LogoCloud.tsx) | Exported, never imported anywhere. Fully dead. |
| `hero={{ imageSrc: ... }}` on all 8 product pages | Passed but never rendered — every page overrides with `customHero`. Dead data. |
| ~68-icon `lucide-react` import block | Copy-pasted verbatim at the top of [Home.tsx](src/pages/Home.tsx) and all 8 product pages. Home uses **none** of them; each product page uses roughly 10–15. |
| `benefits` array in CandidateManagement (lines 127–136) | Five items listed twice for the marquee loop — the duplication is intentional but manual, unlike the `[...arr, ...arr]` spread used elsewhere. |
| Root-level `.mp4` files | Duplicated into `public/` under new names; the originals add ~13.7 MB to the repo with no consumer. |

---

## 7. API Documentation

### 7.1 HTTP API — none exists

**This application has no backend API and makes no network requests.** Verified by repo-wide search across `src/` for `fetch(`, `axios`, `XMLHttpRequest`, `genai`, `GoogleGenAI`, `GEMINI`, `express`, and `process.env` — zero matches.

Three artifacts imply an API that was never built:

| Artifact | Implication | Reality |
|---|---|---|
| `"@google/genai": "^2.4.0"` in dependencies | Gemini AI integration | Never imported |
| `"express": "^4.21.2"` + `"clean": "rm -rf dist server.js"` | An Express server producing `server.js` | No server file exists anywhere in the repo |
| `metadata.json` → `MAJOR_CAPABILITY_SERVER_SIDE_GEMINI_API` | Server-side Gemini enabled | No server-side code |
| `.env.example` → `GEMINI_API_KEY`, `APP_URL` | Runtime configuration | Neither variable is read by any source file |

### 7.2 Internal component API (the actual contracts)

The meaningful "API" in this codebase is the set of component prop contracts.

**`ProductPageLayout(props: ProductPageProps)`** — the primary contract. Full signature in [Section 6.1](#61-productpagelayout--the-systems-keystone). All fields are required except `customHero`; there are no defaults and no runtime validation. Omitting a required field is a TypeScript error caught only by `npm run lint`.

**`Blog.tsx` internal components** (defined in-file, typed `any` — no prop validation):

```ts
ArticleCard({ image, category, featured, date, title, readTime }: any)
CategoryItem({ name, count }: any)
PopularArticleItem({ image, title, readTime }: any)
```

**Zero-prop components** (all content internal): `Navbar`, `Footer`, `ChatbotWidget`, `Hero`, `Mission`, `Features`, `Compliance`, `FeatureHighlight`, `VideoSection`, `Testimonials`, `FAQ`, `FAQContact`, `Insights`, `CTA`, `LogoCloud`, all 8 `*Hero` components, and every routed page.

### 7.3 Routing API

Declared in [src/App.tsx](src/App.tsx) with `BrowserRouter`. No route parameters, no query-string handling, no nested routes, no lazy loading, no route guards, no error boundaries, no catch-all.

**Deployment requirement:** because `BrowserRouter` uses the History API, the hosting layer **must rewrite all unmatched paths to `/index.html`**. Without this, a direct hit or refresh on `/job-management` returns a server 404. Configuration by platform:

| Platform | Required setting |
|---|---|
| Netlify | `_redirects`: `/*  /index.html  200` |
| Vercel | `vercel.json` rewrite: `{ "source": "/(.*)", "destination": "/index.html" }` |
| Nginx | `try_files $uri $uri/ /index.html;` |
| Apache | `.htaccess` with `FallbackResource /index.html` |

### 7.4 Integration surface for future backend work

When the site is made functional, these are the endpoints it will need. **None of this is implemented** — it is the specification implied by the existing UI.

| Endpoint | Method | Consumer | Payload |
|---|---|---|---|
| `/api/contact` | POST | [ContactUs.tsx](src/pages/ContactUs.tsx) form | `firstName, lastName, email, phone, subject, message, consent` |
| `/api/newsletter` | POST | [Footer.tsx](src/components/Footer.tsx) signup | `email` |
| `/api/demo-request` | POST | "Book a Demo" / "Request Demo" buttons (currently no-ops) | `name, email, company, phone` |
| `/api/chat` | POST (or stream) | [ChatbotWidget.tsx](src/components/ChatbotWidget.tsx) | `message, conversationId` → replaces the `setTimeout` stub |
| `/api/posts` | GET | [Blog.tsx](src/pages/Blog.tsx) | Article list; pairs with a new `/blog/:slug` route |

---

## 8. Database Relationships

### 8.1 Current state: no database

**This repository contains no database, no ORM, no schema, no migrations, and no persistence of any kind.** All content is compiled into the JavaScript bundle as literal arrays. Nothing entered by a visitor is stored anywhere — form input is discarded on page unload, and chatbot messages live only in component state.

### 8.2 Conceptual domain model (implied by the marketed product — not implemented)

The eight platform pages describe a coherent recruitment data model. The following is reverse-engineered from that marketing copy and is documented as a **specification for future backend work**, not as a description of existing code.

```
                    ┌───────────────┐
                    │  Organization │  (tenant root)
                    └───────┬───────┘
                            │ 1
        ┌───────────────────┼────────────────────┬──────────────────┐
        │ N                 │ N                  │ N                │ N
   ┌────▼─────┐       ┌─────▼──────┐      ┌──────▼──────┐    ┌──────▼──────┐
   │   User   │       │   Client   │      │   Vendor    │    │  AuditLog   │
   │(recruiter│       │ (hiring    │      │ (staffing   │    │             │
   │ /manager)│       │  company)  │      │  agency)    │    └─────────────┘
   └────┬─────┘       └─────┬──────┘      └──────┬──────┘
        │ N:M               │ 1                  │ N:M
        │             ┌─────▼──────┐             │
        │             │ Requisition│◄────────────┘
        │             │   (Job)    │   vendors submit candidates
        │             └─────┬──────┘   to specific requisitions
        │                   │ 1
        │                   │ N
        │           ┌───────▼────────┐        ┌──────────────┐
        │           │   Application  │───N:1─►│   Candidate  │
        │           │   (Pipeline    │        │  (unified    │
        │           │    Entry)      │        │   profile)   │
        │           └───────┬────────┘        └──────┬───────┘
        │                   │ 1                      │ 1
        │      ┌────────────┼───────────┐            │ N
        │      │ N          │ N         │ N   ┌──────▼────────┐
        │  ┌───▼────┐  ┌────▼─────┐ ┌───▼───┐ │    Resume     │
        └─►│Interview│  │MatchScore│ │ Offer │ │  (parsed doc) │
           └───┬────┘  └──────────┘ └───────┘ └───────────────┘
               │ 1                                   │
               │ N                                   │ N
        ┌──────▼──────┐                    ┌─────────▼─────────┐
        │  Scorecard  │                    │ CommunicationLog  │
        │ (structured │                    │ (email/SMS/       │
        │  feedback)  │                    │  WhatsApp/call)   │
        └─────────────┘                    └───────────────────┘
```

### 8.3 Entity specifications

| Entity | Source page | Key attributes | Relationships |
|---|---|---|---|
| **Organization** | Compliance & Security | Tenant root; RBAC and retention policy scope | 1:N → all other entities |
| **User** | Compliance & Security, Unified Communication | Role (recruiter / hiring manager / admin / client user / vendor user), permission set | N:M ↔ Requisition; 1:N → Interview, CommunicationLog, AuditLog |
| **Client** | Client & Vendor Management | Company profile, contract terms (MSA/SLA), portal access | 1:N → Requisition |
| **Vendor** | Client & Vendor Management | Staffing agency, submittal/interview/placement performance metrics | N:M ↔ Requisition (scoped visibility) |
| **Requisition (Job)** | Job Management | Title, skills, budget, location, status, approval chain state, custom pipeline stage set | N:1 ← Client; 1:N → Application |
| **Candidate** | Candidate Management | **Unified profile** — one record regardless of how many roles they apply to (explicitly stated in the page FAQ) | 1:N → Application, Resume, CommunicationLog |
| **Application (Pipeline Entry)** | Candidate Management | The **join entity** between Candidate and Requisition; carries current stage, timestamps, status | N:1 ← Candidate; N:1 ← Requisition |
| **Resume** | Candidate Management | Original document + parsed skills/experience/contact fields | N:1 ← Candidate |
| **MatchScore** | AI Candidate Matching | Fit percentage, contributing factors, adjustable criteria weights | N:1 ← Application |
| **Interview** | Interview Management | Schedule, panel members, video conference link, stage | N:1 ← Application; N:M ↔ User (panel) |
| **Scorecard** | Interview Management | Structured, standardized evaluation criteria and ratings | N:1 ← Interview |
| **Offer** | Candidate Management (step 08) | Terms, negotiation history, acceptance status | N:1 ← Application |
| **CommunicationLog** | Unified Communication | Channel (email / SMS / WhatsApp / call / internal note), direction, body, thread id. **Stated as immutable** — "a complete, uneditable audit trail" | N:1 ← Candidate; N:1 ← User |
| **AuditLog** | Compliance & Security | Actor, action, target, timestamp. Covers "every action, view, and export" | N:1 ← Organization |

### 8.4 Relationship rules stated in the marketing copy

These are explicit product commitments and should be treated as hard requirements for any implementation:

1. **A candidate has exactly one profile across all applications.** *"Candidates can be associated with multiple positions while maintaining a single unified profile."* → `Candidate ─1:N─ Application ─N:1─ Requisition`; deduplication on ingest is mandatory.
2. **Pipeline stages are per-requisition, not global.** *"Pipelines are fully customizable per job opening."* → stage definitions belong to Requisition; Application references a stage within its own requisition's set.
3. **Approval chains can be sequential or parallel**, keyed on department or budget → the approval workflow needs its own state machine, not a single status column.
4. **Vendor visibility is row-level scoped.** *"Granular permissions ensure vendors only see what they need to."* → authorization must filter at the Application/Candidate level, not just by route.
5. **Communication and audit history are append-only.** Both are described as complete and uneditable → no UPDATE or DELETE on these tables; soft-delete only.
6. **Right-to-be-forgotten must be supported** (GDPR/CCPA/DPDPA) → anonymization must be reconcilable with rule 5; anonymize PII in place while preserving the audit chain.
7. **Silver-medalist re-matching** — past candidates are automatically matched against new openings → Candidate records persist beyond any single requisition's lifecycle, subject to retention policy.

---

## 9. User Workflows

### 9.1 Visitor workflows on this website

**A. Evaluate the product (primary path)**
```
Land on /  →  Hero value prop  →  Mission KPIs  →  Features grid (11 cards)
  →  Compliance badges  →  Why-choose-PyHire  →  Watch demo video
  →  Testimonials  →  FAQ  →  Blog teasers  →  Final CTA
  →  Click "Book a Demo"        ⚠ button has no handler — dead end
```

**B. Research one capability**
```
Navbar → Platform dropdown → pick 1 of 8 modules
  →  Custom hero  →  Features marquee  →  Workflow timeline
  →  Benefits column  →  Module FAQ  →  "Book a Demo Today"   ⚠ dead end
```

**C. Self-serve a question**
```
Home → FAQ section → type a query → Enter (or click a listed question)
  →  substring match against the 9-entry knowledge base
  →  match: answer expands and scrolls into view
  →  no match: fallback message + FAQContact prompt
```

**D. Ask the assistant**
```
Any page → click floating orange bot → panel opens with greeting
  →  type a message → send
  →  1 s delay → fixed canned reply    ⚠ no AI, no routing, no capture
```

**E. Submit an enquiry**
```
/contact-us  →  fill 6 fields + consent checkbox  →  "Send Message"
  →  nothing happens   ⚠ type="button", no handler, no state — lead is lost
```

**F. Read the blog**
```
/blog  →  browse 4 articles / 6 categories / 6 popular posts
  →  click anything  →  nothing happens   ⚠ no article route exists
```

Workflows A–D function as designed. **E and F are broken** and represent the highest-priority fixes.

### 9.2 The marketed 9-step hiring lifecycle

Documented on [CandidateManagement.tsx](src/pages/CandidateManagement.tsx) as the flagship end-to-end workflow — the process the actual PyHire product is claimed to run:

| Step | Stage | Description |
|---|---|---|
| 01 | Candidate Application | Candidates apply via careers page, job portals, or referrals |
| 02 | Resume Parsing | Key information extracted from resumes automatically |
| 03 | Candidate Profile Creation | Structured profiles built with all relevant details |
| 04 | AI Candidate Matching | AI matches candidates to suitable roles by best fit |
| 05 | Recruiter Review | Recruiters review matched candidates and shortlist |
| 06 | Interview Scheduling | Interviews scheduled with selected candidates |
| 07 | Evaluation & Feedback | Feedback collected and candidates evaluated at every stage |
| 08 | Offer Management | Offers sent, negotiations managed, acceptance tracked |
| 09 | Candidate Hired | Selected candidate converted to employee and onboarded |

### 9.3 Module-level workflows (6 steps each)

| Module | Workflow |
|---|---|
| **Job Management** | Draft Requisition → Approval Chain → Job Description → Job Publishing → Sourcing Begins → Pipeline Management |
| **AI Candidate Matching** | Job Requirements → Data Ingestion → Semantic Analysis → Scoring Generation → Ranking → Recruiter Action |
| **Interview Management** | *"Seamless Interview Workflows"* — scheduling through structured feedback collection |
| **Client & Vendor Management** | *"Collaborative Recruitment Workflow"* — requisition intake through client approval of submittals |
| **Unified Communication** | *"How Unified Communication Works"* — omnichannel inbox through automated sequences |
| **Analytics & Dashboards** | *"From Data to Insights"* — capture through executive reporting |
| **Compliance & Security** | *"Secure by Design"* — access control through automated governance |

Each module's six steps live in its page's `workflowSteps` array and render through the shared timeline in [ProductPageLayout](src/components/ProductPageLayout.tsx).

---

## 10. Important Files

### Tier 1 — highest impact

| File | Why it matters |
|---|---|
| [src/components/ProductPageLayout.tsx](src/components/ProductPageLayout.tsx) | **Highest blast radius.** Any edit changes 7 pages at once. Owns 3 of the 4 marquee animations and the `ProductPageProps` contract. |
| [src/App.tsx](src/App.tsx) | Route table and persistent chrome. Every new page is registered here. |
| [src/pages/CandidateManagement.tsx](src/pages/CandidateManagement.tsx) | 37 KB, the only bespoke product page, owner of the 9-step lifecycle and the wavy-timeline geometry. |
| [src/components/Navbar.tsx](src/components/Navbar.tsx) | Navigation source of truth; the `platformLinks` array must stay in sync with `App.tsx` routes and the Footer's Platform column. |

### Tier 2 — content and configuration

| File | Role |
|---|---|
| [src/components/Features.tsx](src/components/Features.tsx) | 24 KB — 11 capability cards with hand-built product mockups; the densest content file |
| [src/components/FAQ.tsx](src/components/FAQ.tsx) | The `knowledgeBase` array is the site's canonical product Q&A |
| [src/components/Footer.tsx](src/components/Footer.tsx) | Sitemap + contact details; duplicates the Platform link list |
| [src/components/Mission.tsx](src/components/Mission.tsx) | The 5 published KPI claims — verify before changing |
| [src/components/Compliance.tsx](src/components/Compliance.tsx) | Compliance badge wording is legally sensitive; the hedged phrasing is deliberate |
| [src/pages/Home.tsx](src/pages/Home.tsx) | Home section order — the funnel sequence |
| [vite.config.ts](vite.config.ts) | Plugins, `@` alias, and the `DISABLE_HMR` escape hatch |
| [package.json](package.json) | Scripts and dependencies (still named `react-example`) |
| [index.html](index.html) | **`<title>` is still "My Google AI Studio App"** — must be fixed before launch |
| [metadata.json](metadata.json) | AI Studio manifest; declares an unused server-side Gemini capability |
| [.env.example](.env.example) | Documents `GEMINI_API_KEY` / `APP_URL`, neither of which is read |

### Tier 3 — one-off codemods (historical, already applied)

These scripts mutated source files in place and have already run. They are **not** part of the build and should not be re-executed — re-running them against current source will either no-op or corrupt files, since their regex targets no longer match.

| Script | What it did |
|---|---|
| [update_app.sh](update_app.sh) | `sed` removal of the `FAQContact` import and usage from `App.tsx` (it now lives inside `FAQ.tsx`) |
| [update_navbar.js](update_navbar.js) | Injected `useLocation` and active-link conditional styling into `Navbar.tsx` |
| [update_product_layout.py](update_product_layout.py) | Converted the workflow timeline from horizontal scroll to the `marqueeWorkflow` animation |
| [update_workflow.py](update_workflow.py) | Rebuilt the CandidateManagement wavy timeline as the `marqueeHorizontal` marquee |

**Recommendation:** delete these four files, or move them to an `archive/` directory. Their presence in the root suggests they are part of the workflow when they are not.

### Static assets

| File | Size | Used by |
|---|---|---|
| `public/ai-recruitment-platform-mvp.mp4` | 3.5 MB | [Hero.tsx](src/components/Hero.tsx) — autoplay, muted, loop |
| `public/pyhire-demo.mp4` | 9.6 MB | [VideoSection.tsx](src/components/VideoSection.tsx) — user-controlled |
| `public/candidate-banner.png` | 1.3 MB | Present; no current reference found in `src/` |
| Root `.mp4` × 2 | 13.7 MB | **Unused duplicates** of the two public videos |

---

## 11. Business Benefits

### 11.1 Benefits PyHire claims to deliver to customers

Aggregated from all eight platform pages — this is the value inventory available for sales and campaign copy.

**Speed**
- Save hundreds of hours by eliminating manual resume screening
- Approvals in hours instead of days — no email sign-off chains
- Eliminate scheduling ping-pong via automated calendar coordination
- Faster feedback loops through automated interviewer reminders

**Quality**
- Improve quality of hire via deep, objective criteria matching
- Objective evaluations through standardized scorecards
- Bias reduction by scoring strictly on qualifications
- Correlate candidate sources with long-term employee success

**Scale**
- Handle thousands of applications effortlessly
- Wider reach through integrated premium job boards
- Reusable talent pools; automatic re-matching of silver medalists
- Multi-user, multi-client, multi-vendor collaboration under RBAC

**Cost and ROI**
- Monitor job-board spend and posting ROI
- Reallocate budget away from underperforming sources
- Improve time-to-fill forecasting from historical data

**Experience**
- Better candidate experience — faster responses, consistent communication
- Higher response rates by reaching candidates on WhatsApp and SMS
- Branded client portals for reviewing submitted talent
- No recruiter context-switching between email, phone, and ATS

**Risk and governance**
- Mitigate breach and compliance risk proactively
- Adhere to international privacy law without manual effort
- Automated retention and data-lifecycle governance
- Complete audit trail of every action, view, and export

### 11.2 Business benefits of this codebase's architecture

| Architectural choice | Commercial benefit |
|---|---|
| Data-driven product pages | A new capability page ships as ~40 lines of content, not a design-and-build cycle — marketing can move at campaign speed |
| Single shared layout | Narrative consistency across all modules is structurally guaranteed; one design change updates 7 pages |
| Static SPA, no backend | Near-zero hosting cost, deployable to any CDN, no server to patch or scale |
| No database or auth | No PII is stored by the marketing site, which materially shrinks the compliance surface for a company selling on compliance |
| Marquee-based content display | Large content volumes fit in small viewport space without pagination, keeping the scroll depth to the CTA short |
| Hand-built JSX mockups (not screenshots) | Product visuals never go stale against a changing real UI; they are crisp at any resolution and cost nothing in image bandwidth |

### 11.3 Business risks currently carried by the site

| Risk | Impact | Priority |
|---|---|---|
| **Contact form silently discards leads** | Every enquiry from the primary conversion page is lost, with the visitor unaware | 🔴 Critical |
| **All demo CTAs are inert** | The site's single most important action does nothing on every page | 🔴 Critical |
| **Newsletter signup does not persist** | List-building traffic is wasted | 🟠 High |
| **Chatbot gives a canned reply to everything** | Visitors expecting an "AI assistant" from an AI company receive an obviously scripted response — an active credibility risk | 🟠 High |
| **Blog links go nowhere** | SEO and content-marketing investment cannot convert; no article pages to rank | 🟠 High |
| **Browser tab reads "My Google AI Studio App"** | Immediately visible unprofessionalism; harms bookmarks, sharing, and search snippets | 🟠 High |
| **No meta description / Open Graph / favicon** | Poor search snippets and unattractive social sharing cards | 🟠 High |
| **Unsplash hot-linked imagery** | Third-party outage or hotlink block degrades every page at once | 🟡 Medium |
| **13.7 MB of video, ~14.9 MB total media** | Slow first paint on mobile; measurable bounce-rate and Core Web Vitals cost | 🟡 Medium |
| **Placeholder `#` links** (Case Studies, Use Cases, social, Privacy Policy, Terms of Use) | Dead navigation erodes trust; **missing Privacy Policy and Terms is a compliance exposure** for a DPDPA/GDPR-positioned vendor | 🟡 Medium |
| **No 404 route** | Mistyped or stale URLs render a blank page between header and footer | 🟡 Medium |

---

## 12. Development Workflow

### 12.1 Prerequisites

- Node.js (LTS recommended)
- npm, or Bun (both lockfiles are present — **pick one and delete the other** to prevent dependency drift)

### 12.2 Setup

```bash
npm install          # or: bun install
npm run dev          # Vite dev server on 0.0.0.0:3000
```

Open http://localhost:3000.

`.env.local` is **not required** — no source file reads any environment variable. `.env.example` documents `GEMINI_API_KEY` and `APP_URL` for a Gemini integration that does not exist yet.

### 12.3 Available scripts

| Script | Command | Purpose |
|---|---|---|
| `npm run dev` | `vite --port=3000 --host=0.0.0.0` | Dev server with HMR, exposed on the local network |
| `npm run build` | `vite build` | Production bundle → `dist/` |
| `npm run preview` | `vite preview` | Serve the production build locally |
| `npm run lint` | `tsc --noEmit` | **Type-check only.** There is no ESLint or Prettier config in this repo |
| `npm run clean` | `rm -rf dist server.js` | Removes build output (the `server.js` reference is vestigial) |

**Note:** `npm run clean` uses Unix `rm -rf` and will fail in PowerShell or cmd. On Windows, use Git Bash, or delete `dist/` manually.

### 12.4 Common development tasks

**Add a new product/platform page**

1. Create `src/pages/NewModuleHero.tsx` — the bespoke hero (model it on [JobManagementHero.tsx](src/pages/JobManagementHero.tsx)).
2. Create `src/pages/NewModule.tsx` returning `<ProductPageLayout customHero={<NewModuleHero />} … />`. Follow the established content shape: 4 features, 6 workflow steps (`"01"`…`"06"`), 4 benefits, 3 FAQs.
3. Register the route in [src/App.tsx](src/App.tsx).
4. Add the link to `platformLinks` in [src/components/Navbar.tsx](src/components/Navbar.tsx).
5. Add the link to the Platform column in [src/components/Footer.tsx](src/components/Footer.tsx).
6. Optionally add a matching card to [src/components/Features.tsx](src/components/Features.tsx).

Steps 3–5 are three separate link lists that must be kept in sync manually. **Consider extracting a shared `platformNav` constant** — this is the single highest-value refactor available in the codebase.

**Edit product copy** — change the data arrays in the relevant `src/pages/*.tsx` file. No layout changes needed.

**Edit the FAQ** — modify `knowledgeBase` in [src/components/FAQ.tsx](src/components/FAQ.tsx). Remember the search is a naive substring match: phrase questions using the words visitors will actually type.

**Change brand color** — currently requires a global find-and-replace of `#f97316` (plus `#ea580c`, `#FF6B00`, `#ff5a1f`, `orange-50`, `orange-100`, `orange-200`, `orange-600`). **Recommended:** define CSS custom properties in [src/index.css](src/index.css) via Tailwind v4's `@theme` block first.

**Change a marquee's speed** — edit the duration in the `animate-[name_40s_linear_infinite]` arbitrary value. **Do not change the array duplication factor without also changing the translate percentage** (2× ↔ −50%, 3× ↔ −33.33%), or the loop will visibly jump.

### 12.5 Conventions to follow

| Convention | Rule |
|---|---|
| Component exports | Named function exports (`export function X()`), except `App.tsx` which is a default export |
| File naming | PascalCase `.tsx` for all components and pages |
| Styling | Tailwind utilities inline; arbitrary values for exact design specs. No CSS modules, no styled-components |
| Icons | lucide-react exclusively |
| Animation | `motion/react` — `initial` / `whileInView` / `viewport={{ once: true }}` for reveals; CSS keyframes for marquees |
| Scroll reset | Every routed page must call `window.scrollTo(0, 0)` in a mount `useEffect` |
| Images | Absolute URLs (currently Unsplash); videos from `/public` |
| Responsive | Mobile-first; provide a non-animated fallback for every desktop-only marquee |

### 12.6 Build and deploy

```bash
npm run build     # → dist/
npm run preview   # verify locally before shipping
```

Deploy `dist/` to any static host. **The SPA fallback rewrite described in [Section 7.3](#73-routing-api) is mandatory** — without it, every route except `/` 404s on direct load.

### 12.7 Quality gates

Currently there are **no automated quality gates**: no tests, no test runner, no ESLint, no Prettier, no CI, no pre-commit hooks, and no git repository initialized in this directory.

`npm run lint` (which is only `tsc --noEmit`) is the sole automated check. Run it before every commit.

**Recommended additions, in order of value:** git init → ESLint + Prettier → CI running `lint` + `build` → Vitest + React Testing Library for the stateful components (FAQ search, Navbar, ChatbotWidget) → Lighthouse budget for the media-heavy home page.

---

## 13. Known Gaps & Technical Debt

Consolidated and prioritized. Items marked 🔴 block a production launch.

### Functional gaps

| # | Gap | Location | Severity |
|---|---|---|---|
| 1 | Contact form does not submit — uncontrolled inputs, no handler, `type="button"` | [ContactUs.tsx:57](src/pages/ContactUs.tsx#L57) | 🔴 |
| 2 | Every "Book a Demo" / "Request Demo" / "Get Free Quote" button lacks an `onClick` | Navbar, Hero, CTA, ProductPageLayout, all hero partials | 🔴 |
| 3 | Newsletter signup does not persist | [Footer.tsx](src/components/Footer.tsx) | 🟠 |
| 4 | Chatbot returns a fixed canned string after a `setTimeout` — no AI, no lead capture | [ChatbotWidget.tsx:32](src/components/ChatbotWidget.tsx#L32) | 🟠 |
| 5 | Blog articles have no detail route; all links are inert; sidebar category counts are fabricated | [Blog.tsx](src/pages/Blog.tsx) | 🟠 |
| 6 | No 404 / catch-all route | [App.tsx](src/App.tsx) | 🟡 |
| 7 | Placeholder `#` links: Case Studies, Use Cases, 4 social icons, Privacy Policy, Terms of Use | Navbar, Footer | 🟡 |

### SEO and metadata

| # | Gap | Severity |
|---|---|---|
| 8 | `<title>` is still "My Google AI Studio App" | 🟠 |
| 9 | No meta description, no Open Graph or Twitter card tags, no favicon | 🟠 |
| 10 | No per-route document title management | 🟡 |
| 11 | No `sitemap.xml`, no `robots.txt` | 🟡 |
| 12 | Client-side-only rendering — crawlers see an empty shell until JS executes; consider SSG/prerendering for a marketing site whose purpose is organic discovery | 🟡 |

### Performance

| # | Gap | Severity |
|---|---|---|
| 13 | 13.1 MB of video plus a 1.3 MB PNG on the critical path | 🟡 |
| 14 | Home hero video autoplays, competing with initial page load | 🟡 |
| 15 | No route-level code splitting — all 12 pages ship in one bundle | 🟡 |
| 16 | Unsplash images are hot-linked, unsized, and not lazy-loaded | 🟡 |
| 17 | Four simultaneous infinite CSS animations on product pages drive continuous compositing | 🟢 |

### Code quality

| # | Item | Severity |
|---|---|---|
| 18 | Package still named `react-example`; README is the unmodified AI Studio scaffold | 🟡 |
| 19 | ~68-icon lucide import block duplicated across 9 files, entirely unused in `Home.tsx` | 🟡 |
| 20 | [LogoCloud.tsx](src/components/LogoCloud.tsx) is dead code | 🟢 |
| 21 | `hero.imageSrc` passed by all 8 product pages but never rendered | 🟢 |
| 22 | 13.7 MB of duplicate `.mp4` files in the repo root | 🟡 |
| 23 | Four applied one-off codemod scripts still sitting in the project root | 🟢 |
| 24 | Two lockfiles (`bun.lock` + `package-lock.json`) risk dependency drift | 🟡 |
| 25 | Platform link list maintained in 3 places (App routes, Navbar, Footer) with no shared constant | 🟡 |
| 26 | `Blog.tsx` sub-components typed `any` | 🟢 |
| 27 | No design tokens — brand colors and radii are repeated as arbitrary Tailwind values throughout | 🟡 |
| 28 | Unused dependencies: `@google/genai`, `express`, `dotenv`, `tsx`, `esbuild`, `autoprefixer` | 🟢 |
| 29 | `metadata.json` declares `MAJOR_CAPABILITY_SERVER_SIDE_GEMINI_API` with no server-side code | 🟢 |
| 30 | No git repository initialized in this directory | 🟠 |

### Accessibility

| # | Gap | Severity |
|---|---|---|
| 31 | Navbar dropdowns are hover-only — not keyboard-reachable | 🟠 |
| 32 | Accordions use `<button>` without `aria-expanded` / `aria-controls` | 🟡 |
| 33 | Marquee animations do not respect `prefers-reduced-motion` | 🟡 |
| 34 | Decorative Unsplash images lack meaningful or empty `alt` text in several places | 🟡 |
| 35 | No skip-to-content link; fixed navbar can obscure anchor targets | 🟢 |

### Suggested launch sequence

1. **Wire lead capture** — items 1, 2, 3 (a form endpoint plus a demo-request modal unblocks all three)
2. **Fix metadata** — items 8, 9
3. **Make the chatbot real or honest** — item 4 (either connect an LLM, or relabel it as a contact form)
4. **Build blog article routes or remove the dead links** — item 5
5. **Publish Privacy Policy and Terms** — item 7 (compliance exposure for a compliance-positioned vendor)
6. **Initialize git and add CI** — items 30, plus [Section 12.7](#127-quality-gates)
7. **Performance pass** — items 13–16
8. **Accessibility pass** — items 31–35
9. **Cleanup** — items 18–29

---

*Documentation generated from a full read of the codebase. Where the site's marketing copy describes capabilities that are not implemented in this repository, that distinction is stated explicitly rather than assumed.*
